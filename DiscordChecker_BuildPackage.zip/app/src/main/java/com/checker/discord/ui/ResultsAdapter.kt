package com.checker.discord.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.checker.discord.data.UsernameResult
import com.checker.discord.databinding.ItemResultBinding

class ResultsAdapter : ListAdapter<UsernameResult, ResultsAdapter.ResultViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ResultViewHolder {
        val binding = ItemResultBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ResultViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ResultViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class ResultViewHolder(private val binding: ItemResultBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(result: UsernameResult) {
            binding.tvUsername.text = result.username
            binding.tvStatus.text = result.status.uppercase()
            binding.tvReason.text = result.reason ?: ""

            val statusColor = when (result.status) {
                "available" -> android.graphics.Color.GREEN
                "taken" -> android.graphics.Color.RED
                "invalid" -> android.graphics.Color.YELLOW
                else -> android.graphics.Color.GRAY
            }
            binding.tvStatus.setTextColor(statusColor)
        }
    }

    private class DiffCallback : DiffUtil.ItemCallback<UsernameResult>() {
        override fun areItemsTheSame(oldItem: UsernameResult, newItem: UsernameResult): Boolean {
            return oldItem.username == newItem.username
        }

        override fun areContentsTheSame(oldItem: UsernameResult, newItem: UsernameResult): Boolean {
            return oldItem == newItem
        }
    }
}
