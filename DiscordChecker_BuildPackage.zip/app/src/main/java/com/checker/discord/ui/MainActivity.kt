package com.checker.discord.ui

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.LinearLayoutManager
import com.checker.discord.data.AppDatabase
import com.checker.discord.data.CheckerRepository
import com.checker.discord.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel
    private lateinit var adapter: ResultsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize database and repository
        val db = AppDatabase.getInstance(this)
        val repository = CheckerRepository(db.resultDao())

        // Initialize ViewModel
        viewModel = ViewModelProvider(this) { MainViewModelFactory(repository) }
            .get(MainViewModel::class.java)

        setupUI()
        observeViewModel()
    }

    private fun setupUI() {
        // RecyclerView setup
        adapter = ResultsAdapter()
        binding.recyclerViewResults.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewResults.adapter = adapter

        // Observe results
        viewModel.allResults.observe(this) { results ->
            adapter.submitList(results)
        }

        // Button listeners
        binding.btnStartCheck.setOnClickListener { startCheck() }
        binding.btnPauseCheck.setOnClickListener { viewModel.pauseCheck() }
        binding.btnClearAll.setOnClickListener { viewModel.clearAll() }

        // Settings
        binding.seekBarLength.setOnSeekBarChangeListener(
            object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                    binding.tvLengthValue.text = (progress + 3).toString()
                }

                override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {}
            }
        )
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.isChecking.collect { isChecking ->
                binding.btnStartCheck.isEnabled = !isChecking
                binding.btnPauseCheck.isEnabled = isChecking
            }
        }

        lifecycleScope.launch {
            viewModel.progress.collect { progress ->
                binding.progressBar.progress = progress
                binding.tvProgress.text = "$progress%"
            }
        }

        lifecycleScope.launch {
            viewModel.currentUsername.collect { username ->
                binding.tvCurrentUsername.text = "Checking: $username"
            }
        }

        lifecycleScope.launch {
            viewModel.availableCount.collect { count ->
                binding.tvAvailableCount.text = "Available: $count"
            }
        }

        lifecycleScope.launch {
            viewModel.takenCount.collect { count ->
                binding.tvTakenCount.text = "Taken: $count"
            }
        }

        lifecycleScope.launch {
            viewModel.invalidCount.collect { count ->
                binding.tvInvalidCount.text = "Invalid: $count"
            }
        }

        lifecycleScope.launch {
            viewModel.uncertainCount.collect { count ->
                binding.tvUncertainCount.text = "Uncertain: $count"
            }
        }
    }

    private fun startCheck() {
        val mode = binding.spinnerMode.selectedItem.toString()

        when (mode) {
            "Generate" -> {
                val length = binding.seekBarLength.progress + 3
                val count = binding.etGenerateCount.text.toString().toIntOrNull() ?: 10

                val includeLetters = binding.cbLetters.isChecked
                val includeNumbers = binding.cbNumbers.isChecked
                val includeDots = binding.cbDots.isChecked
                val includeUnderscores = binding.cbUnderscores.isChecked

                if (!includeLetters && !includeNumbers && !includeDots && !includeUnderscores) {
                    Toast.makeText(this, "Select at least one character type", Toast.LENGTH_SHORT).show()
                    return
                }

                viewModel.generateAndCheck(
                    length = length,
                    count = count,
                    includeLetters = includeLetters,
                    includeNumbers = includeNumbers,
                    includeDots = includeDots,
                    includeUnderscores = includeUnderscores,
                    delayMs = 500
                )
            }
            "Manual" -> {
                val usernames = binding.etManualUsernames.text.toString()
                    .split("\n")
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }

                if (usernames.isEmpty()) {
                    Toast.makeText(this, "Enter at least one username", Toast.LENGTH_SHORT).show()
                    return
                }

                viewModel.startCheck(usernames, delayMs = 500)
            }
        }
    }
}
