package com.checker.discord.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.asLiveData
import com.checker.discord.data.CheckerRepository
import com.checker.discord.data.UsernameResult
import com.checker.discord.util.UsernameGenerator
import com.checker.discord.util.UsernameValidator
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class MainViewModel(private val repository: CheckerRepository) : ViewModel() {

    private val _isChecking = MutableStateFlow(false)
    val isChecking: StateFlow<Boolean> = _isChecking.asStateFlow()

    private val _progress = MutableStateFlow(0)
    val progress: StateFlow<Int> = _progress.asStateFlow()

    private val _currentUsername = MutableStateFlow("")
    val currentUsername: StateFlow<String> = _currentUsername.asStateFlow()

    private val _availableCount = MutableStateFlow(0)
    val availableCount: StateFlow<Int> = _availableCount.asStateFlow()

    private val _takenCount = MutableStateFlow(0)
    val takenCount: StateFlow<Int> = _takenCount.asStateFlow()

    private val _invalidCount = MutableStateFlow(0)
    val invalidCount: StateFlow<Int> = _invalidCount.asStateFlow()

    private val _uncertainCount = MutableStateFlow(0)
    val uncertainCount: StateFlow<Int> = _uncertainCount.asStateFlow()

    val allResults = repository.getResultsFlow().asLiveData()

    private var currentJob: kotlinx.coroutines.Job? = null

    init {
        viewModelScope.launch {
            updateCounts()
        }
    }

    fun startCheck(usernames: List<String>, delayMs: Long = 500) {
        if (_isChecking.value) return

        viewModelScope.launch {
            _isChecking.value = true
            _progress.value = 0

            usernames.forEachIndexed { index, username ->
                _currentUsername.value = username
                repository.checkUsername(username)
                _progress.value = ((index + 1) * 100) / usernames.size
                kotlinx.coroutines.delay(delayMs)
            }

            updateCounts()
            _isChecking.value = false
        }
    }

    fun generateAndCheck(
        length: Int,
        count: Int,
        includeLetters: Boolean = true,
        includeNumbers: Boolean = false,
        includeDots: Boolean = false,
        includeUnderscores: Boolean = false,
        delayMs: Long = 500
    ) {
        viewModelScope.launch {
            val generator = UsernameGenerator(
                length, includeLetters, includeNumbers, includeDots, includeUnderscores
            )
            val generated = generator.generate(count)

            val valid = generated.filter { username ->
                UsernameValidator.validate(username) is com.checker.discord.util.ValidationResult.Valid
            }

            startCheck(valid, delayMs)
        }
    }

    fun pauseCheck() {
        currentJob?.cancel()
        _isChecking.value = false
    }

    fun clearAll() {
        viewModelScope.launch {
            repository.clearAll()
            updateCounts()
            _progress.value = 0
        }
    }

    private suspend fun updateCounts() {
        _availableCount.value = repository.getAvailableCount()
        _takenCount.value = repository.getTakenCount()
        _invalidCount.value = repository.getInvalidCount()
        _uncertainCount.value = repository.getUncertainCount()
    }
}
